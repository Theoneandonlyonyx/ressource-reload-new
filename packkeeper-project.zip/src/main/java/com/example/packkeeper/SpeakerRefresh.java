package com.example.packkeeper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.SoundOptionsScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Adds a "Refresh Speakers" button to the Music & Sounds screen. One click plays a
 * bundled full-scale (maximum amplitude) sound: a square-wave sweep followed by a short
 * melody. Click again while it is playing to stop it.
 */
@Mod.EventBusSubscriber(modid = PackKeeper.MOD_ID, value = Dist.CLIENT)
public class SpeakerRefresh {
    private static final Component LABEL_PLAY = Component.literal("Refresh Speakers");
    private static final Component LABEL_STOP = Component.literal("Stop");

    private static SimpleSoundInstance playing = null;

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof SoundOptionsScreen screen)) {
            return;
        }
        Button button = Button.builder(isPlaying() ? LABEL_STOP : LABEL_PLAY, SpeakerRefresh::toggle)
                .bounds(screen.width - 130, 6, 120, 20)
                .build();
        event.addListener(button);
    }

    private static boolean isPlaying() {
        return playing != null && Minecraft.getInstance().getSoundManager().isActive(playing);
    }

    private static void toggle(Button button) {
        Minecraft mc = Minecraft.getInstance();
        if (isPlaying()) {
            mc.getSoundManager().stop(playing);
            playing = null;
            button.setMessage(LABEL_PLAY);
            return;
        }
        SoundEvent sound = SoundEvent.createVariableRangeEvent(new ResourceLocation(PackKeeper.MOD_ID, "refresh"));
        playing = SimpleSoundInstance.forUI(sound, 1.0F, 1.0F);
        mc.getSoundManager().play(playing);
        button.setMessage(LABEL_STOP);
    }
}
