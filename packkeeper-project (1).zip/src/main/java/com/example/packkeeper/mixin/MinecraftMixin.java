package com.example.packkeeper.mixin;

import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    private static final Logger PACKKEEPER_LOGGER = LoggerFactory.getLogger("PackKeeper");

    /**
     * Vanilla reacts to a failed resource reload (e.g. OutOfMemoryError) by deselecting
     * every resource pack and wiping them from options.txt. Cancel that: the selected packs
     * stay selected and saved until the player removes them manually.
     */
    @Inject(method = "clearResourcePacksOnError", at = @At("HEAD"), cancellable = true)
    private void packkeeper$keepPacks(CallbackInfo ci) {
        PACKKEEPER_LOGGER.warn("Resource reload failed (possibly out of memory). Keeping all selected resource packs instead of resetting them.");
        ci.cancel();
    }
}
