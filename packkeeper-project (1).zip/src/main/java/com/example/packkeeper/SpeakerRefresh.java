package com.example.packkeeper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.SoundOptionsScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Adds a "Refresh Speakers" button to the Music & Sounds screen. One click plays a
 * bundled full-scale (maximum amplitude) sound: a square-wave sweep followed by a short
 * melody. It is as loud as the game can output at 100% volume. Press again to restart it.
 */
@Mod.EventBusSubscriber(modid = PackKeeper.MOD_ID, value = Dist.CLIENT)
public class SpeakerRefresh {
    private static SimpleSoundInstance playing = null;

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof SoundOptionsScreen screen)) {
            return;
        }
        Button button = Button.builder(Component.literal("Refresh Speakers"), b -> play())
                .bounds(screen.width - 130, 6, 120, 20)
                .build();
        event.addListener(button);
    }

    private static void play() {
        Minecraft mc = Minecraft.getInstance();
        if (playing != null) {
            mc.getSoundManager().stop(playing);
        }
        SoundEvent sound = SoundEvent.createVariableRangeEvent(new ResourceLocation(PackKeeper.MOD_ID, "refresh"));
        playing = SimpleSoundInstance.forUI(sound, 1.0F, 1.0F);
        mc.getSoundManager().play(playing);
    }
}
