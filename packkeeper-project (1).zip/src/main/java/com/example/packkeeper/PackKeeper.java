package com.example.packkeeper;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;

/**
 * Pack Keeper: the real work happens in {@link com.example.packkeeper.mixin.MinecraftMixin}.
 * This class only exists so Forge has a mod entry point.
 */
@Mod(PackKeeper.MOD_ID)
public class PackKeeper {
    public static final String MOD_ID = "packkeeper";

    public PackKeeper() {
    }
}
